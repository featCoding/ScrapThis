1.0.0 Adds additional text on some items to give biased suggestions based on personal preferences.
